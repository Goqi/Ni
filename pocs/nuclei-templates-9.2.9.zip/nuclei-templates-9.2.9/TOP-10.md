|    TAG    | COUNT |    AUTHOR     | COUNT |    DIRECTORY     | COUNT | SEVERITY | COUNT |  TYPE   | COUNT |
|-----------|-------|---------------|-------|------------------|-------|----------|-------|---------|-------|
| cve       |  1526 | dhiyaneshdk   |   687 | cves             |  1504 | info     |  1618 | http    |  4218 |
| panel     |   747 | daffainfo     |   659 | exposed-panels   |   751 | high     |  1135 | file    |    77 |
| edb       |   575 | pikpikcu      |   340 | vulnerabilities  |   517 | medium   |   822 | network |    70 |
| xss       |   533 | pdteam        |   274 | misconfiguration |   338 | critical |   540 | dns     |    17 |
| exposure  |   525 | geeknik       |   196 | technologies     |   306 | low      |   260 |         |       |
| lfi       |   518 | dwisiswant0   |   171 | exposures        |   300 | unknown  |    23 |         |       |
| wordpress |   460 | 0x_akoko      |   169 | token-spray      |   235 |          |       |         |       |
| cve2021   |   365 | ritikchaddha  |   159 | workflows        |   190 |          |       |         |       |
| wp-plugin |   355 | pussycat0x    |   157 | default-logins   |   113 |          |       |         |       |
| rce       |   343 | princechaddha |   153 | file             |    77 |          |       |         |       |
